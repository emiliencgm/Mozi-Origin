# 时间 : 2021/08/31 10:16
# 作者 : 张志高
# 文件 : env
# 项目 : 墨子联合作战智能体研发平台
# 版权 : 北京华戍防务技术有限公司

from mozi_ai_sdk.base_env import BaseEnvironment


class Environment(BaseEnvironment):
    """
    环境类
    """
    pass
