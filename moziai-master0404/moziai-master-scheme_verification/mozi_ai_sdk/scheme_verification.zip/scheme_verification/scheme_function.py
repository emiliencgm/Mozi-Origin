# by aie


import re
from scheme_function_done import *
import json
'''
方案构成：完整战役->分成不同阶段->每个阶段的战役级任务->每个战役任务包含的战术级指令行动，
根据任务时间确定任务执行顺序，根据指令触发条件，执行指令
'''
with open('feihai_scheme.json','r',encoding='utf8')as fp:
    scheme_data = json.load(fp)
task_list = []
for campaign_name in scheme_data.keys():
    for campaign_stage in scheme_data.get(campaign_name):
        for stage_name in campaign_stage.keys():
            for task in campaign_stage.get(stage_name):
                for task_name in task.keys():
                    task_list.append(task.get(task_name))
# print(task_list)
# print((len(task_list)))
for task_one in task_list:
    create_mozi_order(side_name, scenario, task_one)


