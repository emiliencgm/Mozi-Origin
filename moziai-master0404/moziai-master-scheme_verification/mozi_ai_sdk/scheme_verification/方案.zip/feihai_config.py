# 任务类型（mission_type），指令类型（order_type）对照表
mission_type = {1: "支援任务", 2: "进攻任务", 3: "压制任务"}
order_type = {12: "新增指令", 13: "更新指令"}
